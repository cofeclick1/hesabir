<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex flex-col justify-center items-center bg-gradient-to-tr from-primary to-accent py-8">
    <div class="w-full max-w-md bg-white rounded-3xl shadow-xl p-8">
        <h2 class="text-3xl font-extrabold text-primary text-center mb-2">ورود به حساب کاربری</h2>
        <p class="text-gray-500 text-center mb-6">لطفا وارد حساب خود شوید</p>
        <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>

            <!-- ایمیل -->
            <div>
                <label for="email" class="block mb-1 font-bold text-gray-700">ایمیل</label>
                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-primary focus:ring-2 focus:ring-primary/30 transition text-right" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- پسورد -->
            <div>
                <label for="password" class="block mb-1 font-bold text-gray-700">رمز عبور</label>
                <input id="password" type="password" name="password" required
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-primary focus:ring-2 focus:ring-primary/30 transition text-right" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- مرا به خاطر بسپار -->
            <div class="flex items-center justify-between mb-3">
                <label class="flex items-center">
                    <input type="checkbox" name="remember" class="rounded text-primary focus:ring-primary border-gray-300">
                    <span class="mr-2 text-sm text-gray-600">مرا به خاطر بسپار</span>
                </label>
                <a class="text-sm text-primary hover:underline" href="<?php echo e(route('password.request')); ?>">فراموشی رمز عبور؟</a>
            </div>

            <button type="submit"
                class="w-full py-3 bg-primary hover:bg-accent text-white font-bold rounded-lg shadow transition">ورود</button>
        </form>

        <p class="mt-6 text-center text-sm text-gray-600">
            حساب کاربری ندارید؟
            <a href="<?php echo e(route('register')); ?>" class="text-accent font-semibold hover:underline">ثبت نام کنید</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hesabir\resources\views/auth/login.blade.php ENDPATH**/ ?>